// AntiAlias ProjectDoc.h : interface of the CAntiAliasProjectDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ANTIALIASPROJECTDOC_H__34049771_59D6_4F68_B85C_9416248EC87E__INCLUDED_)
#define AFX_ANTIALIASPROJECTDOC_H__34049771_59D6_4F68_B85C_9416248EC87E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CAntiAliasProjectDoc : public CDocument
{
protected: // create from serialization only
	CAntiAliasProjectDoc();
	DECLARE_DYNCREATE(CAntiAliasProjectDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAntiAliasProjectDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAntiAliasProjectDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAntiAliasProjectDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANTIALIASPROJECTDOC_H__34049771_59D6_4F68_B85C_9416248EC87E__INCLUDED_)
