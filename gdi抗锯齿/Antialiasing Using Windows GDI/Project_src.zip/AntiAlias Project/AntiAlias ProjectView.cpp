// AntiAlias ProjectView.cpp : implementation of the CAntiAliasProjectView class
//

#include "stdafx.h"
#include "AntiAlias Project.h"

#include "AntiAlias ProjectDoc.h"
#include "AntiAlias ProjectView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAntiAliasProjectView

IMPLEMENT_DYNCREATE(CAntiAliasProjectView, CView)

BEGIN_MESSAGE_MAP(CAntiAliasProjectView, CView)
	//{{AFX_MSG_MAP(CAntiAliasProjectView)
	ON_COMMAND(ID_OPTIONS_2x2, OnOPTIONS2x2)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_2x2, OnUpdateOPTIONS2x2)
	ON_COMMAND(ID_OPTIONS_4x4, OnOPTIONS4x4)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_4x4, OnUpdateOPTIONS4x4)
	ON_COMMAND(ID_OPTIONS_8x8, OnOPTIONS8x8)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_8x8, OnUpdateOPTIONS8x8)
	ON_COMMAND(ID_OPTIONS_12x12, OnOPTIONS12x12)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_12x12, OnUpdateOPTIONS12x12)
	ON_COMMAND(ID_OPTIONS_16x16, OnOPTIONS16x16)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_16x16, OnUpdateOPTIONS16x16)
	ON_COMMAND(ID_OPTIONS_1x1, OnOPTIONS1x1)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_1x1, OnUpdateOPTIONS1x1)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAntiAliasProjectView construction/destruction

CAntiAliasProjectView::CAntiAliasProjectView()
{
	// TODO: add construction code here
}

CAntiAliasProjectView::~CAntiAliasProjectView()
{
	// Destroy memory DC and bitmap
	if (m_hMemDC)
	{
		::SelectObject(m_hMemDC, m_hOldMemBitmap);
		::DeleteDC(m_hMemDC);
		::DeleteObject(m_hMemBitmap);
	}

	// Destroy anti-alias DC and bitmap
	if (m_hAADC)
	{
		::SelectObject(m_hAADC, m_hOldAABitmap);
		::DeleteDC(m_hAADC);
		::DeleteObject(m_hAABitmap);
	}
}

BOOL CAntiAliasProjectView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CAntiAliasProjectView drawing

void CAntiAliasProjectView::OnDraw(CDC* pDC)
{
	CAntiAliasProjectDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	_TCHAR lpszText[1024], lpszDescText[1024], lpszMemoryText[1024], lpszInfoText[1024];

	// Draw caption text
	CFont font;
	font.CreatePointFont(240, _T("Times New Roman"));
	CFont* pOldFont = pDC->SelectObject(&font);
	pDC->TextOut(10, 10, _T("Anti-aliasing by supersampling..."));
	pDC->SelectObject(pOldFont);
	font.DeleteObject();

	// Draw aliased image
	::BitBlt(pDC->m_hDC, 50, 100, 300, 200, m_hMemDC, 0, 0, SRCCOPY);
	_stprintf(lpszText, _T("Aliased image [300x200 pixels]"));
	::TextOut(pDC->m_hDC, 50, 80, lpszText, _tcslen(lpszText));
	::StretchBlt(pDC->m_hDC, 360, 110, 80, 80, m_hMemDC, 140, 30, 20, 20, SRCCOPY);
	::StretchBlt(pDC->m_hDC, 360, 210, 80, 80, m_hMemDC, 150, 50, 20, 20, SRCCOPY);

	// Check anti-aliasing option
	switch (m_dwOption)
	{
		case 0:
		{
			// Draw 2x2 anti-aliazed image
			::BitBlt(pDC->m_hDC, 500, 100, 300, 200, m_hAADC, 0, 0, SRCCOPY);
			_stprintf(lpszText, _T("2x2 anti-aliasing [%d ms]"), m_dwTime);
			::TextOut(pDC->m_hDC, 500, 80, lpszText, _tcslen(lpszText));
			::StretchBlt(pDC->m_hDC, 810, 110, 80, 80, m_hAADC, 140, 30, 20, 20, SRCCOPY);
			::StretchBlt(pDC->m_hDC, 810, 210, 80, 80, m_hAADC, 150, 50, 20, 20, SRCCOPY);
		}
		break;

		case 1:
		{
			// Draw 4x4 anti-aliazed image
			::BitBlt(pDC->m_hDC, 500, 100, 300, 200, m_hAADC, 0, 0, SRCCOPY);
			_stprintf(lpszText, _T("4x4 anti-aliasing [%d ms]"), m_dwTime);
			::TextOut(pDC->m_hDC, 500, 80, lpszText, _tcslen(lpszText));
			::StretchBlt(pDC->m_hDC, 810, 110, 80, 80, m_hAADC, 140, 30, 20, 20, SRCCOPY);
			::StretchBlt(pDC->m_hDC, 810, 210, 80, 80, m_hAADC, 150, 50, 20, 20, SRCCOPY);
		}
		break;

		case 2:
		{
			// Draw 8x8 anti-aliazed image
			::BitBlt(pDC->m_hDC, 500, 100, 300, 200, m_hAADC, 0, 0, SRCCOPY);
			_stprintf(lpszText, _T("8x8 anti-aliasing [%d ms]"), m_dwTime);
			::TextOut(pDC->m_hDC, 500, 80, lpszText, _tcslen(lpszText));
			::StretchBlt(pDC->m_hDC, 810, 110, 80, 80, m_hAADC, 140, 30, 20, 20, SRCCOPY);
			::StretchBlt(pDC->m_hDC, 810, 210, 80, 80, m_hAADC, 150, 50, 20, 20, SRCCOPY);
		}
		break;

		case 3:
		{
			// Draw 12x12 anti-aliazed image
			::BitBlt(pDC->m_hDC, 500, 100, 300, 200, m_hAADC, 0, 0, SRCCOPY);
			_stprintf(lpszText, _T("12x12 anti-aliasing [%d ms]"), m_dwTime);
			::TextOut(pDC->m_hDC, 500, 80, lpszText, _tcslen(lpszText));
			::StretchBlt(pDC->m_hDC, 810, 110, 80, 80, m_hAADC, 140, 30, 20, 20, SRCCOPY);
			::StretchBlt(pDC->m_hDC, 810, 210, 80, 80, m_hAADC, 150, 50, 20, 20, SRCCOPY);
		}
		break;

		case 4:
		{
			// Draw 16x16 anti-aliazed image
			::BitBlt(pDC->m_hDC, 500, 100, 300, 200, m_hAADC, 0, 0, SRCCOPY);
			_stprintf(lpszText, _T("16x16 anti-aliasing [%d ms]"), m_dwTime);
			::TextOut(pDC->m_hDC, 500, 80, lpszText, _tcslen(lpszText));
			::StretchBlt(pDC->m_hDC, 810, 110, 80, 80, m_hAADC, 140, 30, 20, 20, SRCCOPY);
			::StretchBlt(pDC->m_hDC, 810, 210, 80, 80, m_hAADC, 150, 50, 20, 20, SRCCOPY);
		}
		break;

		default:
		{
			// Draw aliased image
			::BitBlt(pDC->m_hDC, 500, 100, 300, 200, m_hMemDC, 0, 0, SRCCOPY);
			_stprintf(lpszText, _T("Aliased image [%d ms]"), m_dwTime);
			::TextOut(pDC->m_hDC, 500, 80, lpszText, _tcslen(lpszText));
			::StretchBlt(pDC->m_hDC, 810, 110, 80, 80, m_hMemDC, 140, 30, 20, 20, SRCCOPY);
			::StretchBlt(pDC->m_hDC, 810, 210, 80, 80, m_hMemDC, 150, 50, 20, 20, SRCCOPY);
		}
		break;
	}

	// Draw memory text
	_stprintf(lpszMemoryText, _T("Memory required: %d MB"), m_dwMemory>>20);
	::TextOut(pDC->m_hDC, 580, 300, lpszMemoryText, _tcslen(lpszMemoryText));

	// Draw description and info text
	RECT textRect = {100, 350, 600, 600};
	_tcscpy(lpszDescText, _T("This is a simple example of using anti-aliasing technique called Super-Sampling. "));
	_tcscat(lpszDescText, _T("It is achieved by rendering the original image at higher frequency. "));
	_tcscat(lpszDescText, _T("This high-frequency image is then scaled down to the size of the original image and drawn on the screen. "));
	_tcscat(lpszDescText, _T("The scaled image looks better and has less jaggies then the original image."));
	_tcscat(lpszDescText, _T("\n\n"));
	_tcscat(lpszDescText, _T("The cost of this operation is the memory required to render the high-frequency image. "));
	_tcscat(lpszDescText, _T("Also, there is an additional time needed to scale down the high-frequency image to the size of the original image."));
	_tcscat(lpszDescText, _T("\n\n"));
	_tcscat(lpszDescText, _T("Use the OPTIONS menu above to change the high-frequency image size. "));
	_tcscat(lpszDescText, _T("Also, check the time needed to complete this operation using plain Windows GDI."));
	CFont fontDesc;
	fontDesc.CreatePointFont(120, _T("Times New Roman"));
	CFont* pOldFontDesc = pDC->SelectObject(&fontDesc);
	::DrawText(pDC->m_hDC, lpszDescText, _tcslen(lpszDescText), &textRect, DT_WORDBREAK);
	::Rectangle(pDC->m_hDC, 690, 368, 890, 390);
	_stprintf(lpszInfoText, _T("Anti-Aliasing Information"));
	::TextOut(pDC->m_hDC, 700, 369, lpszInfoText, _tcslen(lpszInfoText));
	::Rectangle(pDC->m_hDC, 690, 390, 890, 470);
	_stprintf(lpszInfoText, _T("Creation time: %d ms"), m_dwCreationTime);
	::TextOut(pDC->m_hDC, 700, 400, lpszInfoText, _tcslen(lpszInfoText));
	_stprintf(lpszInfoText, _T("Drawing time: %d ms"), m_dwDrawingTime);
	::TextOut(pDC->m_hDC, 700, 420, lpszInfoText, _tcslen(lpszInfoText));
	_stprintf(lpszInfoText, _T("  Scaling time: %d ms"), m_dwScalingTime);
	::TextOut(pDC->m_hDC, 700, 440, lpszInfoText, _tcslen(lpszInfoText));
	pDC->SelectObject(pOldFontDesc);
	fontDesc.DeleteObject();
}

/////////////////////////////////////////////////////////////////////////////
// CAntiAliasProjectView printing

BOOL CAntiAliasProjectView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CAntiAliasProjectView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CAntiAliasProjectView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CAntiAliasProjectView diagnostics

#ifdef _DEBUG
void CAntiAliasProjectView::AssertValid() const
{
	CView::AssertValid();
}

void CAntiAliasProjectView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAntiAliasProjectDoc* CAntiAliasProjectView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAntiAliasProjectDoc)));
	return (CAntiAliasProjectDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAntiAliasProjectView message handlers

void CAntiAliasProjectView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// Get screen DC
	HDC hDC = ::GetDC(NULL);

	// Create memory DC and bitmap
	m_hMemDC = ::CreateCompatibleDC(hDC);
	m_hMemBitmap = ::CreateCompatibleBitmap(hDC, 300, 200);
	m_hOldMemBitmap = (HBITMAP)::SelectObject(m_hMemDC, m_hMemBitmap);

	// Create anti-alias DC and bitmap
	m_hAADC = ::CreateCompatibleDC(hDC);
	m_hAABitmap = ::CreateCompatibleBitmap(hDC, 300, 200);
	m_hOldAABitmap = (HBITMAP)::SelectObject(m_hAADC, m_hAABitmap);

	// Release screen DC
	::ReleaseDC(NULL, hDC);

	// Create drawing
	CreateDrawing(m_hMemDC, 1);

	// Show aliazed image
	OnOPTIONS1x1();
}

void CAntiAliasProjectView::CreateDrawing(HDC hDrawingDC, int scale)
{
	// Create GDI objects
	HPEN hRedPen = ::CreatePen(PS_SOLID, scale*1, RGB(255,0,0));
	HPEN hGreenPen = ::CreatePen(PS_SOLID, scale*2, RGB(0,255,0));
	HPEN hBluePen = ::CreatePen(PS_SOLID, scale*3, RGB(0,0,255));
	HPEN hYellowPen = ::CreatePen(PS_SOLID, scale*4, RGB(255,255,0));
	HPEN hPurplePen = ::CreatePen(PS_SOLID, scale*5, RGB(255,0,255));
	HPEN hOldPen = (HPEN)::GetCurrentObject(hDrawingDC, OBJ_PEN);
	HBRUSH hOldBrush = (HBRUSH)::GetCurrentObject(hDrawingDC, OBJ_BRUSH);

	// Draw some shapes
	::SelectObject(hDrawingDC, hRedPen);
	::MoveToEx(hDrawingDC, scale*20, scale*20, NULL);
	::LineTo(hDrawingDC, scale*250, scale*50);
	::SelectObject(hDrawingDC, hBluePen);
	::MoveToEx(hDrawingDC, scale*60, scale*50, NULL);
	::LineTo(hDrawingDC, scale*200, scale*30);
	::SelectObject(hDrawingDC, hGreenPen);
	::SelectObject(hDrawingDC, (HBRUSH)GetStockObject(HOLLOW_BRUSH));
	::RoundRect(hDrawingDC, scale*40, scale*40, scale*100, scale*150, scale*50, scale*50);
	::SelectObject(hDrawingDC, hYellowPen);
	::Ellipse(hDrawingDC, scale*120, scale*60, scale*220, scale*100);
	::SelectObject(hDrawingDC, hPurplePen);
	::Pie(hDrawingDC, scale*120, scale*120, scale*220, scale*160, scale*220, scale*140, scale*130, scale*130);

	// Draw some text
	LOGFONT lf;
	lf.lfHeight = -MulDiv(scale*14, ::GetDeviceCaps(::GetDC(NULL), LOGPIXELSY), 72);
	lf.lfWidth = 0;
	lf.lfEscapement = 0;
	lf.lfOrientation = 0;
	lf.lfWeight = FW_BOLD;
	lf.lfItalic = FALSE;
	lf.lfUnderline = FALSE;
	lf.lfStrikeOut = FALSE;
	lf.lfCharSet = DEFAULT_CHARSET;
	lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
	lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	lf.lfQuality = DEFAULT_QUALITY;
	lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
	_tcscpy(lf.lfFaceName, _T("Times New Roman"));
	HFONT hFont = ::CreateFontIndirect(&lf);
	HFONT hOldFont = (HFONT)::SelectObject(hDrawingDC, hFont);
	LPTSTR lpszText = _T("This is a sample image...");
	int oldBkMode = ::SetBkMode(hDrawingDC, TRANSPARENT);
	COLORREF oldTextColor = ::SetTextColor(hDrawingDC, RGB(0,255,255));
	::TextOut(hDrawingDC, scale*60, scale*170, lpszText, _tcslen(lpszText));
	::SelectObject(hDrawingDC, hOldFont);
	::DeleteObject(hFont);
	::SetTextColor(hDrawingDC, oldTextColor);
	::SetBkMode(hDrawingDC, oldBkMode);

	// Destroy GDI objects
	::SelectObject(hDrawingDC, hOldBrush);
	::SelectObject(hDrawingDC, hOldPen);
	::DeleteObject(hRedPen);
	::DeleteObject(hGreenPen);
	::DeleteObject(hBluePen);
	::DeleteObject(hYellowPen);
	::DeleteObject(hPurplePen);
}

void CAntiAliasProjectView::CreateAAImage(HDC hAADC, int scale)
{
	DWORD startTime, endTime;

	// Calculate memory requested
	m_dwMemory = (scale*300) * (scale*200) * 4;

	// Get screen DC
	HDC hDC = ::GetDC(NULL);

	// Create temporary DC and bitmap
	startTime = GetTickCount();
	HDC hTempDC = ::CreateCompatibleDC(hDC);
	HBITMAP hTempBitmap = ::CreateCompatibleBitmap(hDC, scale*300, scale*200);
	HBITMAP hOldTempBitmap = (HBITMAP)::SelectObject(hTempDC, hTempBitmap);
	endTime = GetTickCount();
	m_dwCreationTime = endTime - startTime;

	// Release screen DC
	::ReleaseDC(NULL, hDC);

	// Create drawing
	startTime = GetTickCount();
	CreateDrawing(hTempDC, scale);
	endTime = GetTickCount();
	m_dwDrawingTime = endTime - startTime;

/*	// Copy temporary DC to anti-aliazed DC
	startTime = GetTickCount();
	int oldStretchBltMode = ::SetStretchBltMode(hAADC, HALFTONE);
	::StretchBlt(hAADC, 0, 0, 300, 200, hTempDC, 0, 0, scale*300, scale*200, SRCCOPY);
	::SetStretchBltMode(hAADC, oldStretchBltMode);
	endTime = GetTickCount();
	m_dwScalingTime = endTime - startTime;*/

	startTime = GetTickCount();

	// Get source bits
	int srcWidth = scale * 300;
	int srcHeight = scale * 200;
	int srcPitch = srcWidth * 4;
	int srcSize = srcWidth * srcPitch;
	BYTE* lpSrcBits = new BYTE[srcSize];
	GetBitmapBits(hTempBitmap, srcSize, lpSrcBits);

	// Get destination bits
	int dstWidth = 300;
	int dstHeight = 200;
	int dstPitch = dstWidth * 4;
	int dstSize = dstWidth * dstPitch;
	BYTE* lpDstBits = new BYTE[dstSize];
	HBITMAP hAABitmap = (HBITMAP)GetCurrentObject(hAADC, OBJ_BITMAP);
	GetBitmapBits(hAABitmap, dstSize, lpDstBits);

	int gridSize = scale * scale;
	int resultRed, resultGreen, resultBlue;
	int dstX, dstY=0, dstOffset;
	int srcX, srcY, srcOffset;
	int tmpX, tmpY, tmpOffset;
	for (int y=1; y<dstHeight-2; y++)
	{
		dstX = 0;
		srcX = 0;
		srcY = (y * scale) * srcPitch;
		for (int x=1; x<dstWidth-2; x++)
		{
			srcX = (x * scale) * 4;
			srcOffset = srcY + srcX;

			resultRed = resultGreen = resultBlue = 0;
			tmpY = -srcPitch;
			for (int i=0; i<scale; i++)
			{
				tmpX = -4;
				for (int j=0; j<scale; j++)
				{
					tmpOffset = tmpY + tmpX;

					resultRed += lpSrcBits[srcOffset+tmpOffset+2];
					resultGreen += lpSrcBits[srcOffset+tmpOffset+1];
					resultBlue += lpSrcBits[srcOffset+tmpOffset];
					
					tmpX += 4;
				}
				tmpY += srcPitch;
			}

			dstOffset = dstY + dstX;
			lpDstBits[dstOffset+2] = (BYTE)(resultRed / gridSize);
			lpDstBits[dstOffset+1] = (BYTE)(resultGreen / gridSize);
			lpDstBits[dstOffset] = (BYTE)(resultBlue / gridSize);
			dstX += 4;
		}

		dstY += dstPitch;
	}
	SetBitmapBits(hAABitmap, dstSize, lpDstBits);

	// Destroy source bits
	delete lpSrcBits;

	// Destroy destination bits
	delete lpDstBits;

	endTime = GetTickCount();

	m_dwScalingTime = endTime - startTime;

	// Destroy temporary DC and bitmap
	if (hTempDC)
	{
		::SelectObject(hTempDC, hOldTempBitmap);
		::DeleteDC(hTempDC);
		::DeleteObject(hTempBitmap);
	}
}

void CAntiAliasProjectView::OnOPTIONS1x1() 
{
	// Show aliazed image
	DWORD startTime, endTime;
	startTime = GetTickCount();
	CreateAAImage(m_hAADC, 1);
	endTime = GetTickCount();
	m_dwTime = endTime - startTime;
	m_dwOption = -1;

	// Refresh window
	Invalidate(TRUE);	
}

void CAntiAliasProjectView::OnUpdateOPTIONS1x1(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_dwOption==-1);
}

void CAntiAliasProjectView::OnOPTIONS2x2() 
{
	// Create anti-aliazed image
	DWORD startTime, endTime;
	startTime = GetTickCount();
	CreateAAImage(m_hAADC, 2);
	endTime = GetTickCount();
	m_dwTime = endTime - startTime;
	m_dwOption = 0;

	// Refresh window
	Invalidate(TRUE);
}

void CAntiAliasProjectView::OnUpdateOPTIONS2x2(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_dwOption==0);
}

void CAntiAliasProjectView::OnOPTIONS4x4() 
{
	// Create anti-aliazed image
	DWORD startTime, endTime;
	startTime = GetTickCount();
	CreateAAImage(m_hAADC, 4);
	endTime = GetTickCount();
	m_dwTime = endTime - startTime;
	m_dwOption = 1;

	// Refresh window
	Invalidate(TRUE);
}

void CAntiAliasProjectView::OnUpdateOPTIONS4x4(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_dwOption==1);
}

void CAntiAliasProjectView::OnOPTIONS8x8() 
{
	// Create anti-aliazed image
	DWORD startTime, endTime;
	startTime = GetTickCount();
	CreateAAImage(m_hAADC, 8);
	endTime = GetTickCount();
	m_dwTime = endTime - startTime;
	m_dwOption = 2;

	// Refresh window
	Invalidate(TRUE);
}

void CAntiAliasProjectView::OnUpdateOPTIONS8x8(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_dwOption==2);
}

void CAntiAliasProjectView::OnOPTIONS12x12() 
{
	// Create anti-aliazed image
	DWORD startTime, endTime;
	startTime = GetTickCount();
	CreateAAImage(m_hAADC, 12);
	endTime = GetTickCount();
	m_dwTime = endTime - startTime;
	m_dwOption = 3;

	// Refresh window
	Invalidate(TRUE);
}

void CAntiAliasProjectView::OnUpdateOPTIONS12x12(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_dwOption==3);
}

void CAntiAliasProjectView::OnOPTIONS16x16() 
{
	// Create anti-aliazed image
	DWORD startTime, endTime;
	startTime = GetTickCount();
	CreateAAImage(m_hAADC, 16);
	endTime = GetTickCount();
	m_dwTime = endTime - startTime;
	m_dwOption = 4;

	// Refresh window
	Invalidate(TRUE);
}

void CAntiAliasProjectView::OnUpdateOPTIONS16x16(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_dwOption==4);	
}
