// AntiAlias ProjectView.h : interface of the CAntiAliasProjectView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ANTIALIASPROJECTVIEW_H__3929D566_584D_4638_806E_E5A33A17FD25__INCLUDED_)
#define AFX_ANTIALIASPROJECTVIEW_H__3929D566_584D_4638_806E_E5A33A17FD25__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CAntiAliasProjectView : public CView
{
protected: // create from serialization only
	CAntiAliasProjectView();
	DECLARE_DYNCREATE(CAntiAliasProjectView)

// Attributes
public:
	CAntiAliasProjectDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAntiAliasProjectView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAntiAliasProjectView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAntiAliasProjectView)
	afx_msg void OnOPTIONS2x2();
	afx_msg void OnUpdateOPTIONS2x2(CCmdUI* pCmdUI);
	afx_msg void OnOPTIONS4x4();
	afx_msg void OnUpdateOPTIONS4x4(CCmdUI* pCmdUI);
	afx_msg void OnOPTIONS8x8();
	afx_msg void OnUpdateOPTIONS8x8(CCmdUI* pCmdUI);
	afx_msg void OnOPTIONS12x12();
	afx_msg void OnUpdateOPTIONS12x12(CCmdUI* pCmdUI);
	afx_msg void OnOPTIONS16x16();
	afx_msg void OnUpdateOPTIONS16x16(CCmdUI* pCmdUI);
	afx_msg void OnOPTIONS1x1();
	afx_msg void OnUpdateOPTIONS1x1(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	DWORD m_dwScalingTime;
	DWORD m_dwDrawingTime;
	DWORD m_dwCreationTime;
	DWORD m_dwMemory;
	DWORD m_dwOption;
	DWORD m_dwTime;
	HBITMAP m_hOldAABitmap;
	HBITMAP m_hAABitmap;
	HDC m_hAADC;
	HBITMAP m_hOldMemBitmap;
	HBITMAP m_hMemBitmap;
	HDC m_hMemDC;
	void CreateAAImage(HDC hAADC, int scale);
	void CreateDrawing(HDC hDrawingDC, int scale);
};

#ifndef _DEBUG  // debug version in AntiAlias ProjectView.cpp
inline CAntiAliasProjectDoc* CAntiAliasProjectView::GetDocument()
   { return (CAntiAliasProjectDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANTIALIASPROJECTVIEW_H__3929D566_584D_4638_806E_E5A33A17FD25__INCLUDED_)
